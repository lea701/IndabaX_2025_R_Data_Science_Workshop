# ---------------------------------------
# IndabaX 2025 R Workshop: Getting Started with R
# Author: Leaname Abram and Seipone Sebina
# Dataset: Global Indicators (alcohol, income, suicide, employment, urbanization)
# ---------------------------------------

# Load required packages
library(tidyverse)

# Optional: Clean formatting
#options(scipen = 999)

# Load the dataset
data <- read_csv("C:/Users/LeanameAbram/Desktop/IndabaX-R in Data Science/R_Workshop_Dataset.csv")

# Preview the data
glimpse(data)
summary(data)
head(data)

# Basic Data Cleaning
# Check for missing values
colSums(is.na(data))

# For workshop purposes, we’ll drop any rows with *any* NAs
clean_data <- data %>% drop_na()

#check how many rows were dropped
nrow(data) - nrow(clean_data)

summary(clean_data)
tail(clean_data)

#top 10 countries by alcohol consumption
clean_data %>% 
  arrange(desc(alcconsumption)) %>% 
  select(country, alcconsumption) %>% 
  head(10)

# Correlation matrix (quick glance at relationships)
clean_data %>% 
  select(-country) %>% 
  cor() %>% 
  round(2)


# 📈 VISUALIZATION

# Alcohol consumption vs suicide rate
ggplot(clean_data, aes(x = alcconsumption, y = suicideper100th)) +
  geom_point(color = "#3B82F6") +
  geom_smooth(method = "lm", se = FALSE, color = "red") +
  labs(
    title = "Alcohol Consumption vs. Suicide Rate",
    x = "Alcohol Consumption (litres/person/year)",
    y = "Suicides per 100k",
    caption = "Source: IndabaX Workshop Dataset"
  ) +
  theme_minimal()

# Income vs Urbanization
ggplot(clean_data, aes(x = incomeperperson, y = urbanrate)) +
  geom_point(aes(color = employrate), alpha = 0.7) +
  scale_color_gradient(low = "red", high = "blue") +
  labs(
    title = "Income vs. Urbanization",
    x = "Income per Person (USD)",
    y = "Urbanization Rate (%)",
    color = "Employment Rate (%)"
  ) +
  theme_classic()

# Histogram of suicide rates
ggplot(clean_data, aes(x = suicideper100th)) +
  geom_histogram(fill = "blue", bins = 20, alpha = 0.9) +
  labs(
    title = "Distribution of Suicide Rates",
    x = "Suicides per 100k",
    y = "Number of Countries"
  ) +
  theme_light()